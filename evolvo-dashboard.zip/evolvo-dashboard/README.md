# Evolvo Digital — Client Dashboard

Live client reporting dashboard connected to Supabase.

## Deploy to Vercel

1. Upload this entire folder to a GitHub repo
2. Go to vercel.com → Add New Project → Import that repo
3. Vercel auto-detects Create React App — just click Deploy
4. Done. Your dashboard is live.

## File Structure

```
evolvo-dashboard/
├── public/
│   └── index.html
├── src/
│   ├── index.js
│   └── App.jsx        ← Main dashboard (edit Supabase credentials here)
├── package.json
└── vercel.json
```

## Updating Client Data

Log into supabase.com → your project → Table Editor → find the client → update their numbers.
The dashboard pulls fresh data every time it loads.
